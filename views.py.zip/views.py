from django.shortcuts import redirect


def index2(request):
    return redirect('/app/')

# def index3(request):
#     return redirect('/marketingapp/')    
    